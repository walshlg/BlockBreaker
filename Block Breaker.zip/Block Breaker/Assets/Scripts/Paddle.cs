﻿using UnityEngine;
using System.Collections;

public class Paddle : MonoBehaviour {
 
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		Vector3 paddlePos = new Vector3(this.transform.position.x,this.transform.position.y,0f);

		float mousePosInBlocksX = (Input.mousePosition.x / Screen.width *16);
		float mousePosInBlocksY = (Input.mousePosition.y / Screen.height *12);
		paddlePos.x = Mathf.Clamp (mousePosInBlocksX, 0.5f, 15.5f);
	//	paddlePos.y = Mathf.Clamp (mousePosInBlocksY, 0.5f, 5f); // allows y movement of paddle
		this.transform.position = paddlePos;
		
			
		}
		
}
