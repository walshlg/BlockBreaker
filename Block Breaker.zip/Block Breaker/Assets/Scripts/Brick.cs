﻿using UnityEngine;
using System.Collections;

public class Brick : MonoBehaviour {
	
	public AudioClip crack;
	public static int breakableCount = 0;
	public Sprite[] hitSprites;
	
	private int timesHit;  //number of times hit
	private LevelManager levelManager;
	private bool isBreakable;
  
	void Start () {
		isBreakable = (this.tag == "Breakable");
		// keep track of breakable Bricks
		if (isBreakable) {
			breakableCount ++;
		}
		
		timesHit = 0;
		levelManager = GameObject.FindObjectOfType<LevelManager>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	
	void OnCollisionEnter2D (Collision2D col){
		print ("Brick has colided");
		AudioSource.PlayClipAtPoint (crack , transform.position, 0.05f);
		bool isBreakable = (this.tag == "Breakable");
		if(isBreakable){
			HandleHits ();
		}
	}
			
		void HandleHits() { // max number of hits can have
			timesHit ++;
			int maxHits=hitSprites.Length+1;// max number of hits can have
			if(timesHit>=maxHits){
				breakableCount --;
				//print ("breakableCount= "+ breakableCount);
				levelManager.BrickDestroyed();
				Destroy (gameObject);
			}
			else{
			LoadSprites();			
			}
		}
			
			
		void LoadSprites(){
			int spriteIndex = timesHit -1;
			if(hitSprites [spriteIndex] != null){
				this.GetComponent<SpriteRenderer>().sprite = hitSprites[spriteIndex];
			}
		}
			
	//TODO - remove this method once get game working for a real win			
	//	void SimulateWin(){
	//		levelManager.LoadNextLevel();
	
}

