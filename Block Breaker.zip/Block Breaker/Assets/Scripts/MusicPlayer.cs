﻿using UnityEngine;
using System.Collections;

public class MusicPlayer : MonoBehaviour {
static  MusicPlayer instance = null;

	void Awake() {
		Debug.Log ("MusicPlayer called from Awake " + GetInstanceID());	
		if (instance != null) {
			Destroy (gameObject);
			print ("Duplicate Music player self destructed");
		}
		else {
			instance = this;	
			Debug.Log ("MusicPlayer instance is null " + GetInstanceID());	
			GameObject.DontDestroyOnLoad(gameObject);
		}	
	}


	void Start () {
		Debug.Log ("MusicPlayer called from Start " + GetInstanceID());	
	}
	
	
	// Update is called once per frame
	void Update () {
	
	}
}
