﻿using UnityEngine;
using System.Collections;

public class Ball : MonoBehaviour {

	public AudioClip boing;
	private Paddle paddle;
	private Vector3 paddleToBallVector;
	private bool hasStarted= false;// has the game started?
	// private Vector2 addedForce = new Vector2 (0.5f, 0.0f); 
	// how much sideways force to add to prevent stalling loop of ball with zero change in x	
	
	void Start () {
		paddle = GameObject.FindObjectOfType<Paddle>();
		paddleToBallVector = this.transform.position - paddle.transform.position; //the offset to paddle
	//  print (paddleToBallVector.y);
 	 	audio.Play ();
	}
	
 
	void Update () {
		if (!hasStarted){// do while game not started
			this.transform.position = paddle.transform.position + paddleToBallVector;//locks ball relative to paddle
			if (Input.GetMouseButtonDown (0)){
				print ("left mouse button clicked so Launch Ball!");
				this.GetComponent<Rigidbody2D>().velocity = new Vector2 (2f, 10f);//shoot ball up
			//	this.rigidbody2D.AddTorque(0.6f,ForceMode2D.Impulse);//MAKES THE BALL SPIN
				hasStarted = true;//game has started
			}
		}
	
	}
	void OnCollisionEnter2d (Collision2D col){
		print ("Ball has collided");
		if (hasStarted){
			AudioSource.PlayClipAtPoint (boing , transform.position, 0.5f);
		}
	}
}
